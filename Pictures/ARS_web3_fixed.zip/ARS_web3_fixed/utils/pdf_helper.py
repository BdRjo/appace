"""
Arabic PDF helper — registers ArabicFont and provides reshaping utility.
Falls back gracefully if font file is missing.
"""
import os

FONT_PATH      = os.path.join(os.path.dirname(__file__), '..', 'static', 'fonts', 'ArabicFont.ttf')
FONT_BOLD_PATH = os.path.join(os.path.dirname(__file__), '..', 'static', 'fonts', 'ArabicFontBold.ttf')

_registered = False

def register_arabic_font():
    """Register ArabicFont with ReportLab. Call once per process."""
    global _registered
    if _registered:
        return True
    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        if os.path.exists(FONT_PATH):
            pdfmetrics.registerFont(TTFont('ArabicFont', FONT_PATH))
        if os.path.exists(FONT_BOLD_PATH):
            pdfmetrics.registerFont(TTFont('ArabicFontBold', FONT_BOLD_PATH))
        _registered = True
        return True
    except Exception:
        return False

def ar(text):
    """
    Reshape Arabic text for correct ReportLab rendering.
    If arabic_reshaper / bidi are unavailable returns text reversed
    so at least individual characters show (better than nothing).
    """
    if not text:
        return text
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(str(text)))
    except ImportError:
        # Reverse words to approximate RTL in LTR engine
        words = str(text).split()
        return ' '.join(reversed(words))

def arabic_font(bold=False):
    """Return registered font name, or fallback."""
    reg = register_arabic_font()
    if reg:
        return 'ArabicFontBold' if (bold and os.path.exists(FONT_BOLD_PATH)) else 'ArabicFont'
    return 'Helvetica-Bold' if bold else 'Helvetica'
